
import { createConnectionObject } from "../Config/dbconfig.js";

const conection = createConnectionObject();

//create
export function saveapp(request, response){
   try {
    
    const  app = request.body;
    console.log(app);
    const insertQuery = `insert into purchase (course_name, buyer_name, course_price) values('${app.course_name}','${app.buyer_name}',${app.course_price})`;
    conection.query(insertQuery,(error)=>{
        if(error) {
            console.log(error);    
            response.status(500).send({message:"something went to wrong"});    
        }
        else{
            response.status(201).send({message:"new course purchased successfuly"});
        }
    });
   } 
   catch (error) {
        response.status(500).send({message: "something went wrong"});    
    }
}

//get 
export function getapp(request,response){
    try{
        const app = request.body;
        const selectQuery= `select * from purchase`;
        conection.query(selectQuery,(error,result)=>{
            if(error){
                response.status(500).send({message:"Error to find app"});
                return;
            }
            response.status(200).send(result);
        })
    }catch(error){
        response.status(500).send({message:"Error to find app"});
    }
};

// update
export function updateapp(request, response) {
    try {
        const coureseId = request.params.id;
        const app = request.body;
        
        const updateQuery = `update purchase set course_name='${app.course_name}',buyer_name= '${app.buyer_name}', course_price = '${app.course_price}'where id=${coureseId}`;
        conection.query(updateQuery, (error, result) => {
            if (error) {
                console.log(error);
                response.status(500).send({ message: "Error updating app data" });
                return;
            }
            response.status(200).send({ message: "course related data updated successfully" });
        })
    } catch (error) {
        response.status(500).send({ message: "Error to updating app data"});
    }
};


// delete
export function deleteapp(request, response) {
    try {     
        const coureseId = request.params.id;
        const deleteQuery = `delete from purchase where id=${coureseId}`;
        conection.query(deleteQuery, (error, result) => {
            if (error) {
                console.log(error);
                response.status(500).send({ message: "Error deleting app" });
                return;
            }
            response.status(200).send({ message: "course data deleted successfully" });
        })
    } catch (error) {
        response.status(500).send({ message: "Error deleting app" });
    }
};